These folders contain the files required to update the CC3100 BoosterPack with the LightServer html and images files.

You will need to open ls.ucf in the uniflash_template folder with UniFlash for the CC3100/CC3200. To ensure the paths work as expected, you will need to copy the contents of the zip into the c:\lightserver\ folder

More details can be found at the LightServer Wiki - https://github.com/remixed123/LightServer/wiki

